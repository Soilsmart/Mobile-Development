package com.azkaisnandaru.farmerapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.recyclerview.widget.LinearLayoutManager
import com.azkaisnandaru.farmerapp.adapter.DataAdapter
import com.azkaisnandaru.farmerapp.databinding.ActivityPrediksiBinding
import com.azkaisnandaru.farmerapp.model.DataPrediksi
import com.azkaisnandaru.farmerapp.model.dummyData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class PrediksiActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPrediksiBinding
    private lateinit var  prediksiadapter: DataAdapter
    private val prediksiList = ArrayList<DataPrediksi>()
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPrediksiBinding.inflate(layoutInflater)
        setContentView(binding.root)
        auth = Firebase.auth

        prediksiadapter = DataAdapter(prediksiList)
        binding.rvPrediksi.layoutManager = LinearLayoutManager(applicationContext)
        binding.rvPrediksi.adapter = DataAdapter(prediksiList)

        prediksiList.addAll(dummyData)
        prediksiadapter.notifyDataSetChanged()

        binding.fabAdd.setOnClickListener{
            startActivity(Intent(this@PrediksiActivity, TambahDataActivity::class.java))
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_profile -> {
                val intent = Intent(this@PrediksiActivity, ProfileActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.menu_logout ->{
                auth.signOut()
                val intent = Intent(this@PrediksiActivity, MainActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}

