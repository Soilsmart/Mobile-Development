package com.azkaisnandaru.farmerapp.model

import com.google.gson.annotations.SerializedName

data class HistoryPredictionResponse(
    @SerializedName("code")
    val code: Int,
    @SerializedName("data")
    val data: List<DataPrediksi>
)
