package com.azkaisnandaru.farmerapp.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

//@Parcelize
//data class DataPrediksi (
//    val namaLahan: String,
//    val jenisPanen: String,
//    val luasLahan: String,
//    val tglTanam: String,
//    val perkiraanHasilPanen: String,
//    val perkiraanTglPanen: String,
//    val prediksiPenghasilan: String
//): Parcelable

data class DataPrediksi(
    val namaLahan: String,
    val luasLahan: String,
    val tglTanam: String,
    val jenisPanen: String,
    val perkiraanHasilPanen: String,
    val perkiraanTglPanen: String,
    val prediksiPenghasilan: String
)

val dummyData = listOf(
    DataPrediksi(
        "Lahan A",
        "10 Ha",
        "2023-06-20",
        "Padi",
        "50 Ton",
        "2023-09-30",
        "$50,000"
    ),
    DataPrediksi(
        "Lahan B",
        "5 Ha",
        "2023-07-10",
        "Jagung",
        "30 Ton",
        "2023-11-15",
        "$35,000"
    ),
    DataPrediksi(
        "Lahan C",
        "8 Ha",
        "2023-08-05",
        "Kedelai",
        "20 Ton",
        "2023-10-20",
        "$25,000"
    )
)
