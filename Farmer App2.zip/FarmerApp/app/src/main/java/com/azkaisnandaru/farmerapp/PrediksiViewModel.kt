package com.azkaisnandaru.farmerapp

import androidx.lifecycle.ViewModel

class PrediksiViewModel():ViewModel() {

}