package com.azkaisnandaru.farmerapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.azkaisnandaru.farmerapp.databinding.ActivityTambahDataBinding

class TambahDataActivity : AppCompatActivity() {
    private lateinit var binding : ActivityTambahDataBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTambahDataBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }
}