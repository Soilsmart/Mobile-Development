package com.azkaisnandaru.farmerapp.model

data class LoginResult(
    val name: String,
    val token: String,
    val userId: String
)
