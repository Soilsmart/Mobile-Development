package com.azkaisnandaru.farmerapp.network

import com.azkaisnandaru.farmerapp.model.*
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("/api/historyprediction")
    fun getHistoryPrediction(@Query("email") email: String): Call<HistoryPredictionResponse>

    @POST("/api/predict")
    @FormUrlEncoded
    fun predict(
        @Field("email") email: String,
        @Field("periode_tanam") periodeTanam: Int,
        @Field("luas_panen") luasPanen: Int
    ): Call<PredictionResponse>
}