package com.azkaisnandaru.farmerapp.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.azkaisnandaru.farmerapp.R
import com.azkaisnandaru.farmerapp.databinding.ItemPrediksiBinding
import com.azkaisnandaru.farmerapp.model.DataPrediksi


class DataAdapter(private val listData: ArrayList<DataPrediksi>) : RecyclerView.Adapter<DataAdapter.ViewHolder>() {

    var onItemClick: ((DataPrediksi) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_prediksi, parent, false))

    override fun getItemCount(): Int = listData.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = listData[position]
        holder.bind(data)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val binding = ItemPrediksiBinding.bind(itemView)

        fun bind(data: DataPrediksi) {
            with(binding) {
                tvNamaLahan.text = data.namaLahan
                tvLuasLahan.text = data.luasLahan
                tvTglTanam.text = data.tglTanam
                tvJenisPanen.text = data.jenisPanen
                tvPerkiraanHasilPanen.text = data.perkiraanHasilPanen
                tvPerkiraanTanggalPanen.text = data.perkiraanTglPanen
                tvPrediksiRevenue.text = data.prediksiPenghasilan
            }
        }

        init {
            binding.root.setOnClickListener {
                onItemClick?.invoke(listData[adapterPosition])
            }
        }
    }
}
